const Vacio = () => {
  return <article className="d-none"></article>;
};

export default Vacio;
